//
//  Users.swift
//  Swiftagram
//
//  Created by 土屋陽香 on 2016/07/12.
//  Copyright © 2016年 Haruka Tsuchiya. All rights reserved.
//

import UIKit

class Users {
    static func myUser() -> User {
        return User(username: "yuzushioh", profileImage: "yuzushioh", number: 1)
    }
}
