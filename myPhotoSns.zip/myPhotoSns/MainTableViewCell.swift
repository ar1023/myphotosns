//
//  MainTableViewCell.swift
//  myPhotoSns
//
//  Created by 土屋陽香 on 2016/07/13.
//  Copyright © 2016年 Haruka Tsuchiya. All rights reserved.
//

import UIKit

class MainTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
