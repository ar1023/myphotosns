//
//  CollectionViewCell.swift
//  myPhotoSns
//
//  Created by 土屋陽香 on 2016/07/13.
//  Copyright © 2016年 Haruka Tsuchiya. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}
